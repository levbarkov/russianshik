<?
$MESS["MB_PULLDOWN_PULL"] = "Pull down to refresh";
$MESS["MB_PULLDOWN_DOWN"] = "Release to refresh";
$MESS["MB_PULLDOWN_LOADING"] = "Updating data...";
$MESS["MB_CART"] = "Shopping cart";
?>