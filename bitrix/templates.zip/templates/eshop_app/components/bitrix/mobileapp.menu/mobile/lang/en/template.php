<?
$MESS["MB_AUTH"] = "Log in";
$MESS["MB_EXIT"] = "Exit";
$MESS["PULL_TEXT"] = "Pull down to refresh...";
$MESS["DOWN_TEXT"] = "Release to refresh...";
$MESS["LOAD_TEXT"] = "Updating the menu...";
?>