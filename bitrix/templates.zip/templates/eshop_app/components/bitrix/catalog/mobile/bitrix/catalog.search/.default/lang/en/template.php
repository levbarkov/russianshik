<?
$MESS["CT_BCSE_NOT_FOUND"] = "Unfortunately, no items have been found.";
?>