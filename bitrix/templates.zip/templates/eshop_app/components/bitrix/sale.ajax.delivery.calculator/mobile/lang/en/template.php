<?
$MESS ['SADC_DOCALC'] = "Calculate price";
$MESS ['SALE_SADC_RESULT'] = "Price estimation";
$MESS ['SALE_SADC_TRANSIT'] = "Transit time (days)";
?>
