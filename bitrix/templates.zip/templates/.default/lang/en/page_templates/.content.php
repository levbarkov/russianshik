<?
$MESS ['standart'] = "Standard page";
$MESS ['page_inc'] = "Include area for page";
$MESS ['sect_inc'] = "Include area for section";
?>