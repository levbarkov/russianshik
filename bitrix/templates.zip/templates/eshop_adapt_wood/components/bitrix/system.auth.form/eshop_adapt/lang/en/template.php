<?
$MESS["AUTH_LOGIN"] = "Log In";
$MESS["AUTH_REGISTER"] = "Register";
$MESS["AUTH_LOGOUT"] = "Log Out";
?>