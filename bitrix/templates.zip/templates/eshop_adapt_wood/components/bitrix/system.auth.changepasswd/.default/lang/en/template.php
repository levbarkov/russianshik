<?
$MESS["AUTH_CHANGE_PASSWORD"] = "Password changing";
$MESS["AUTH_LOGIN"] = "Login:";
$MESS["AUTH_CHECKWORD"] = "Check string:";
$MESS["AUTH_NEW_PASSWORD"] = "New Password:";
$MESS["AUTH_NEW_PASSWORD_CONFIRM"] = "Password Confirmation:";
$MESS["AUTH_CHANGE"] = "Change password";
$MESS["AUTH_REQ"] = "Required fields";
$MESS["AUTH_AUTH"] = "Authorization";
$MESS["AUTH_NEW_PASSWORD_REQ"] = "New Password:";
$MESS["AUTH_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["AUTH_NONSECURE_NOTE"] = "The password will be sent in open form. Enable JavaScript in your web browser to enable password encryption.";
?>