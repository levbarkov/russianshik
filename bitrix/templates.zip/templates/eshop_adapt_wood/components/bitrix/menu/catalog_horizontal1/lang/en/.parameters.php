<?
$MESS["MENU_THEME"] = "Menu theme";
$MESS["F_THEME_SITE"] = "Use site theme (for bitrix.eshop)";
$MESS["F_THEME_BLUE"] = "Blue";
$MESS["F_THEME_WOOD"] = "Bark";
$MESS["F_THEME_YELLOW"] = "Yellow";
$MESS["F_THEME_GREEN"] = "Green";
$MESS["F_THEME_RED"] = "Red";
$MESS["F_THEME_BLACK"] = "Dark";
?>