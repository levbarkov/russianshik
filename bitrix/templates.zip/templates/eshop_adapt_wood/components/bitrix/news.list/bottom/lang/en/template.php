<?
$MESS["SDNW_ALLNEWS"] = "All news";
$MESS["NEWS_TITLE"] = "What's new?";
?>