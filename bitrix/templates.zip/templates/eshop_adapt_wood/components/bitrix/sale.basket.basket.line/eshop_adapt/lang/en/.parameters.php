<?
$MESS["PARAM_BUY_URL_SIGN"] = "Add-to-cart Flag";
?>