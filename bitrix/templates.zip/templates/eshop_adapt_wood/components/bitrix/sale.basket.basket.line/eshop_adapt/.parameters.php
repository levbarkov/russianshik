<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

$arTemplateParameters = array(
	"BUY_URL_SIGN" => array(
		'NAME' => GetMessage('PARAM_BUY_URL_SIGN'),
		'TYPE' => 'STRING',
		'DEFAULT' => 'action=ADD2BASKET',
	)
);
?>