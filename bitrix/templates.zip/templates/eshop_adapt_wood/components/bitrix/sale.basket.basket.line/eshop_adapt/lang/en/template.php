<?
$MESS["YOUR_CART"] = "Your cart <span id=\"bx_cart_num\">(#NUM#)</span>";
$MESS["YOUR_CART_EMPTY"] = "Your cart is empty";
?>