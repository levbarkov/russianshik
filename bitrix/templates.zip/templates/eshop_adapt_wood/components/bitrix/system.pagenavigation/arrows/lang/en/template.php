<?
$MESS["nav_paged"] = "Paged";
$MESS["nav_all"] = "All";
$MESS["pages"] = "Pages:";
$MESS["nav_from"] = "of";
?>