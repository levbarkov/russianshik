<?
$MESS["AUTH_REGISTER"] = "Register";
$MESS["AUTH_NAME"] = "Name:";
$MESS["AUTH_LAST_NAME"] = "Last Name:";
$MESS["AUTH_LOGIN_MIN"] = "Login (min. 3 char.)";
$MESS["AUTH_CONFIRM"] = "Password confirmation:";
$MESS["CAPTCHA_REGF_TITLE"] = "Please type the word you see in the image";
$MESS["CAPTCHA_REGF_PROMT"] = "Type text from image";
$MESS["AUTH_REQ"] = "Required fields";
$MESS["AUTH_AUTH"] = "Authorization";
$MESS["AUTH_PASSWORD_REQ"] = "Password:";
$MESS["AUTH_EMAIL_WILL_BE_SENT"] = "A registration confirmation request will be sent to the specified e-mail address.";
$MESS["AUTH_EMAIL_SENT"] = "A registration confirmation request has been sent to the specified e-mail address.";
$MESS["AUTH_EMAIL"] = "E-Mail:";
$MESS["AUTH_SECURE_NOTE"] = "The password will be encrypted before it is sent. This will prevent the password from appearing in open form over data transmission channels.";
$MESS["AUTH_NONSECURE_NOTE"] = "The password will be sent in open form. Enable JavaScript in your web browser to enable password encryption.";
?>