<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Show element date";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Show element title";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Show element detail image";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Show element preview text";
?>