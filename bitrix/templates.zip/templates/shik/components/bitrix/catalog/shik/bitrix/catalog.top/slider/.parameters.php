<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters['ROTATE_TIMER'] = array(
	'PARENT' => 'VISUAL',
	'NAME' => GetMessage('CP_BCT_TPL_ROTATE_TIMER'),
	'TYPE' => 'STRING',
	'DEFAULT' => '30'
);
?>